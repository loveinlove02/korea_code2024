import tkinter as tk
from PIL import Image, ImageTk


class SelectPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)
        self.create_widgets()

    def create_widgets(self):
        self.select_page_fm = tk.Frame(self, highlightbackground='#B8D1F5', 
                                             highlightthickness=2,
                                             bg='#FFFFFF')
        self.select_page_fm.pack(pady=0)
        self.select_page_fm.configure(width=890, height=780)


# root = tk.Tk()
# select_page = SelectPage(root)
# root.title("Select Page")
# root.geometry("900x800")
# select_page.pack(fill="both", expand=True)
# root.mainloop()        