import tkinter as tk
from PIL import Image, ImageTk


class ScanBorrowPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)
        self.create_widgets()


    def create_widgets(self):
        self.scan_borrow_page_fm = tk.Frame(self, 
                                            highlightbackground='#B8D1F5', 
                                            highlightthickness=2, bg='#FFFFFF')
        self.scan_borrow_page_fm.pack(pady=0)
        self.scan_borrow_page_fm.configure(width=890, height=780)



# root = tk.Tk()
# scan_borrow_page = ScanBorrowPage(root)
# root.title("ScanBorrow Page")
# root.geometry("900x800")
# scan_borrow_page.pack(fill="both", expand=True)
# root.mainloop()