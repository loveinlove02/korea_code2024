import tkinter as tk
from PIL import Image, ImageTk


class ReturnPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)
        self.create_widgets()

    def create_widgets(self):
        self.welcome_page_fm = tk.Frame(self, highlightbackground='#B8D1F5', 
                                              highlightthickness=2, bg='#FFFFFF')
        self.welcome_page_fm.pack(pady=0)
        self.welcome_page_fm.configure(width=890, height=780)


# root = tk.Tk()
# return_page = ReturnPage(root)
# root.title("Return Page")
# root.geometry("900x800")
# return_page.pack(fill="both", expand=True)
# root.mainloop()