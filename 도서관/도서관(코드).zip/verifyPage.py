import tkinter as tk
from PIL import Image, ImageTk


class VerifyPage(tk.Frame):
    def __init__(self, container):
        super().__init__(container)
        self.create_widgets()

    def create_widgets(self):
        self.verify_page_fm = tk.Frame(self, 
                                       highlightbackground='#B8D1F5', 
                                       highlightthickness=2, bg='#FFFFFF')
        self.verify_page_fm.pack(pady=0)
        self.verify_page_fm.configure(width=890, height=780)


# root = tk.Tk()
# verify_page = VerifyPage(root)
# root.title("Verify Page")
# root.geometry("900x800")
# verify_page.pack(fill="both", expand=True)
# root.mainloop()        