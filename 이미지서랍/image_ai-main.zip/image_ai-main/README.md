# 이미지 서랍
# 파이어베이스<br>
## [1. Realtime Database 만들기](https://www.youtube.com/watch?v=WMlS_489hiE)<br>
## [2. 앱인벤터와 Realtime Database 연동하기](https://www.youtube.com/watch?v=VJ6hssw0Wgo&t=583s)<br>
## [3. 앱인벤터 파이어베이스1](https://www.youtube.com/watch?v=6ilUCFquEeI&t=3s)<br>
## [4. 앱인벤터 파이어베이스2](https://www.youtube.com/watch?v=UpTXMoyJL3A) <br>

# 설치파일 입니다<br>
## [파이썬 설치파일](https://drive.google.com/file/d/1PABXsZEF385c1DAmCMXBJlmFd6QeDOkm/view?usp=sharing) <br>
## [파이참 설치파일](https://drive.google.com/file/d/12A2nKEi1Jfg9LYO9LiA__CCD6cG1JPKk/view?usp=sharing) <br>

## [파이참 프로젝트 생성](https://www.youtube.com/watch?v=xgMY2RriGLM) <br>
## [파이어베이스 사용하기](https://youtu.be/i4RNBbPOwqc?si=DeBGCGMSX2Ed8z1j)<br>
## [파이어베이스 사용하기 (데이터조회)](https://youtu.be/2nkk-Bnj13A?si=kdMlTpisI2o5C2U4)<br>
## [파이어베이스 사용하기 (데이터등록)](https://youtu.be/e9g9DNjd3Yk?si=1vf-NAzM4jPRoLU-)<br>
## [파이어베이스 사용하기 (데이터 삭제)](https://youtu.be/Tpm23Nd0DSU?si=UWTOvLP9W5P45t8u)<br>
