# crow

## 라이브러리

pip install jupyter

pip install ipykernel

pip install numpy==1.26.4

pip install opencv-contrib-python

pip install pillow

pip install python-dotenv

pip install firebase_admin

pip install openai


http://arduino.esp8266.com/stable/package_esp8266com_index.json

보드 매니저 - esp8266 - 3.0.2

라이브러리 - Firebase ESP8266 Client 3.9.5
